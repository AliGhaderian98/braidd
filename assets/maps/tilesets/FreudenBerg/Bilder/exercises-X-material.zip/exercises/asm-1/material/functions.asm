; (C) 2017 H. Rittich
; Auxiliary functions for Linux x86 kernel access.

SECTION .text

; Standard Ouput
%define STDOUT 1

; Syscalls
%define SYS_EXIT 1
%define SYS_WRITE 4

; a function prologue that stores the registers allocates stack space
; takes stack size as argument
%macro prologue 1
  ; macro context
  %push stackframe
  %define %$stack_size %1

  ; create stack frame
  push ebp
  mov ebp, esp

  ; allocate space on the stack for local variables
  %if %$stack_size > 0
    sub esp, %$stack_size
  %endif

  ; save registers
  push eax
  push ebx
  push ecx
  push edx
%endmacro

; function cleanup
%macro epilogue 0
  ; restore registers
  pop edx
  pop ecx
  pop ebx
  pop eax

  ; clean up the stack
  %if %$stack_size > 0
    add esp, %$stack_size
  %endif
  pop ebp

  ; remove macro context
  %pop stackframe
%endmacro

; Print a string (4 bytes length + text).
; The address of the string has to be pushed to the stack.
print_str:
  prologue 0
  %define %$text_ptr [ebp+8]

  mov edx, %$text_ptr   ; number of bytes
  mov edx, [edx]        ; deref
  mov ecx, %$text_ptr   ; address
  add ecx, 4
  mov ebx, STDOUT     ; stream
  mov eax, SYS_WRITE  ; syscall
  int 80h             ; execute syscall

  epilogue
  ret 4 ; return and pop 4 bytes of the stack


; Print a number.
; The number has to be pushed onto the stack.
print_num:
  prologue 28

  ; arguments
  %define %$num dword [ebp+8]

  ; local variables
  %define %$buf [ebp-16]
  %define %$count dword [ebp-20]
  %define %$remain dword [ebp-24]
  %define %$buf_ptr dword [ebp-28]

  mov %$count, 1
  mov %$remain, 0

  ; address of last character of the buffer -> buf_ptr
  lea eax, %$buf
  add eax, 16
  mov %$buf_ptr, eax

  ; store new line character at end of buffer
  mov eax, %$buf_ptr
  mov byte [eax], 0Ah

  ; convert to string loop
print_num_div_step:
  ; divide edx:eax by ebx
  mov edx, 0
  mov eax, %$num
  mov ebx, 10
  div ebx

  mov %$num, eax    ; result -> num
  mov %$remain, edx ; remainder -> remain

  add %$remain, 30h  ; convert to ASCII

  ; move buffer ptr to next free position
  dec %$buf_ptr

  ; store in buffer
  mov eax, %$buf_ptr
  mov ebx, %$remain
  mov byte [eax], BL

  inc %$count ; increase number of digits

  cmp %$num, 0 ; the result
  jnz print_num_div_step

  mov edx, %$count   ; number of bytes
  mov ecx, %$buf_ptr ; address of string
  mov ebx, STDOUT
  mov eax, SYS_WRITE
  int 80h

  epilogue
  ret 4

; Quit the program nicely
exit:
  mov     ebx, 0          ; return 0
  mov     eax, SYS_EXIT
  int     80h
