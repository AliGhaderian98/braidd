%include "functions.asm"

SECTION .data

; assign msg variable with your message string
msg: dd 13             ; number of characters
     db 'Hello World!', 0Ah ; text + newline

SECTION .text
global  _start

_start:

  push msg
  call print_str

  push dword 42
  call print_num

  push dword 5938
  call print_num

  call exit
