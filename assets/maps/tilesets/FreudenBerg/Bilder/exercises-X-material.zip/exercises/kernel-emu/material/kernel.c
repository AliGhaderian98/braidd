
#define COLS 80
#define ROWS 25

/* Screen attributes:
 *
 * Lower nibble: text color
 * Upper nibble: background color
 *
 *    0 black
 *    1 blue
 *    2 green
 *    3 cyan
 *    4 red
 *    5 magenta
 *    6 brown
 *    7 white
 *    8 gray
 *    9 bright blue
 *    a bright green
 *    b bright cyan
 *    c bright red
 *    d bright magenta
 *    e yellow
 *    f bright white
 */

void main(void)
{
	return;
}
