bits 32                     ; nasm 32 bit
section .data
	align 4                  ; Align to 32 bit
	;

section .text
global _start
extern main

_start:
	cli                      ; Clear global interrupt flag
	;
	hlt                      ; Halt the CPU

section .bss
	;
